import streamlit as st
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

# Load the trained models
# Open the RandomForestClassifier model for ExerciseName

with open('RandomForestClassifier_ExerciseName.pkl', 'rb') as pickle_in_ExerciseName:
    rfc_ExerciseName = pickle.load(pickle_in_ExerciseName)

# Open the RandomForestClassifier model for ExerciseImage
with open('RandomForestClassifier_ExerciseImage.pkl', 'rb') as pickle_in_ExerciseImage:
    rfc_ExerciseImage = pickle.load(pickle_in_ExerciseImage)

# Open the RandomForestClassifier model for Equipment
with open('RandomForestClassifier_Equipment.pkl', 'rb') as pickle_in_Equipment:
    rfc_Equipment = pickle.load(pickle_in_Equipment)

# Open the RandomForestClassifier model for level
with open('RandomForestClassifier_Level.pkl', 'rb') as pickle_in_Level:
    rfc_Level = pickle.load(pickle_in_Level)

# Open the RandomForestClassifier model for Description
with open('RandomForestClassifier_Description.pkl', 'rb') as pickle_in_Description:
    rfc_Description = pickle.load(pickle_in_Description)

# Open the RandomForestClassifier model for Duration
with open('RandomForestClassifier_Duration.pkl', 'rb') as pickle_in_Duration:
    rfc_Duration = pickle.load(pickle_in_Duration)

# Open the RandomForestClassifier model for DaysPerWeek
with open('RandomForestClassifier_DaysPerWeek.pkl', 'rb') as pickle_in_DaysPerWeek:
    rfc_DaysPerWeek = pickle.load(pickle_in_DaysPerWeek)

# Open the RandomForestClassifier model for TimePerWorkout
with open('RandomForestClassifier_TimePerWorkout.pkl', 'rb') as pickle_in_TimePerWorkout:
    rfc_TimePerWorkout = pickle.load(pickle_in_TimePerWorkout)

# Open the RandomForestClassifier model for RecommendedSupplements
with open('RandomForestClassifier_RecommendedSupplements.pkl', 'rb') as pickle_in_RecommendedSupplements:
    rfc_RecommendedSupplements = pickle.load(pickle_in_RecommendedSupplements)

# Open the RandomForestClassifier model for WorkoutPdfwithvideo
with open('RandomForestClassifier_WorkoutPdfwithvideo.pkl', 'rb') as pickle_in_WorkoutPdfwithvideo:
    rfc_WorkoutPdfwithvideo = pickle.load(pickle_in_WorkoutPdfwithvideo)


with open('df.pkl', 'rb') as pickle_in_df:
    exercise = pickle.load(pickle_in_df)

# Load the LabelEncoders for decoding predictions
# Load the LabelEncoder for 'ExerciseName'
with open('le_ExerciseName.pkl', 'rb') as encoder_file:
    encoder_ExerciseName = pickle.load(encoder_file)

# Load the LabelEncoder for 'ExerciseImage'
with open('le_ExerciseImage.pkl', 'rb') as encoder_file:
    encoder_ExerciseImage = pickle.load(encoder_file)

# Load the LabelEncoder for 'Equipment'
with open('le_Equipment.pkl', 'rb') as encoder_file:
    encoder_Equipment = pickle.load(encoder_file)

# Load the LabelEncoder for 'level'
with open('le_Level.pkl', 'rb') as encoder_file:
    encoder_level = pickle.load(encoder_file)

# Load the LabelEncoder for 'Description'
with open('le_Description.pkl', 'rb') as encoder_file:
    encoder_Description = pickle.load(encoder_file)

# Load the LabelEncoder for 'Duration'
with open('le_Duration.pkl', 'rb') as encoder_file:
    encoder_Duration = pickle.load(encoder_file)

with open('le_DaysPerWeek.pkl', 'rb') as encoder_file:
    encoder_DaysPerWeek = pickle.load(encoder_file)


# Load the LabelEncoder for 'TimePerWorkout'
with open('le_TimePerWorkout.pkl', 'rb') as encoder_file:
    encoder_TimePerWorkout = pickle.load(encoder_file)

# Load the LabelEncoder for 'RecommendedSupplements'
with open('le_RecommendedSupplements.pkl', 'rb') as encoder_file:
    encoder_RecommendedSupplements = pickle.load(encoder_file)

# Load the LabelEncoder for 'WorkoutPdfwithvideo'
with open('le_WorkoutPdfwithvideo.pkl', 'rb') as encoder_file:
    encoder_WorkoutPdfwithvideo = pickle.load(encoder_file)

## Load the LabelEncoder for 'Goal' (input feature)
with open('le_Goal.pkl', 'rb') as encoder_file:
    encoder_Goal = pickle.load(encoder_file)

# Load the LabelEncoder for 'Gender' (input feature)
with open('le_Gender.pkl', 'rb') as encoder_file:
    encoder_Gender = pickle.load(encoder_file)

exercise_df = pd.read_csv("git exercise.csv")

# Define the Streamlit app
st.title('Exercise Prediction App')
st.text("Designed by Project Team 1 Scrum Team 5")

# Define feature names in the correct order
feature_names = ['Gender', 'Goal']

# Input section
st.sidebar.header("INPUT YOUR DETAILS AND GOAL")
# Create select boxes for input features
selected_gender = st.sidebar.selectbox("What is your gender:", exercise_df['Gender'].unique())
#selected_goal = st.sidebar.selectbox("What do you want to achieve:", exercise_df['Goal'].unique())
# Filter workout goals based on the selected gender
available_goals = exercise_df[exercise_df['Gender'] == selected_gender]['Goal'].unique()

selected_goal = st.sidebar.selectbox("What do you want to achieve:", available_goals)

# Create a variable to store human-readable values for display
display_gender = selected_gender
display_goal = selected_goal


if st.sidebar.button("Predict"):
    # Encode the selected gender and goal using the loaded LabelEncoders
    encoded_gender = encoder_Gender.transform([selected_gender])[0]
    encoded_goal = encoder_Goal.transform([selected_goal])[0]

    # Filter exercises based on the selected gender
    filtered_exercise_df = exercise_df[(exercise_df['Gender'] == selected_gender) & (exercise_df['Goal'] == selected_goal)]

    if not filtered_exercise_df.empty:
        # Prepare input features for prediction
    # Prepare input features for prediction
        input_data = np.array([[encoded_gender, encoded_goal]])

# Make predictions
        predicted_ExerciseName = encoder_ExerciseName.inverse_transform(rfc_ExerciseName.predict(input_data))
        predicted_ExerciseImage = encoder_ExerciseImage.inverse_transform(rfc_ExerciseImage.predict(input_data))
        predicted_Equipment = encoder_Equipment.inverse_transform(rfc_Equipment.predict(input_data))
        predicted_level = encoder_level.inverse_transform(rfc_Level.predict(input_data))
        predicted_Description = encoder_Description.inverse_transform(rfc_Description.predict(input_data))
        predicted_Duration = encoder_Duration.inverse_transform(rfc_Duration.predict(input_data))
        predicted_DaysPerWeek = encoder_DaysPerWeek.inverse_transform(rfc_DaysPerWeek.predict(input_data)) 
        predicted_TimePerWorkout = encoder_TimePerWorkout.inverse_transform(rfc_TimePerWorkout.predict(input_data))
        predicted_RecommendedSupplements = encoder_RecommendedSupplements.inverse_transform(rfc_RecommendedSupplements.predict(input_data))
        predicted_WorkoutPdfwithvideo = encoder_WorkoutPdfwithvideo.inverse_transform(rfc_WorkoutPdfwithvideo.predict(input_data))

# Display the predicted results
        st.subheader("Predicted Results:")
        st.write("Exercise Name:", predicted_ExerciseName[0])
        st.write("Exercise Image:", predicted_ExerciseImage[0])
        st.write("Equipment:", predicted_Equipment[0])
        st.write("Level:", predicted_level[0])
        st.write("Description:", predicted_Description[0])
        st.write("Duration:", predicted_Duration[0])
        st.write("Days Per Week:", predicted_DaysPerWeek[0])
        st.write("Time Per Workout:", predicted_TimePerWorkout[0])
        st.write("Recommended Supplements:", predicted_RecommendedSupplements[0])
        st.write("Workout PDF with Video:", predicted_WorkoutPdfwithvideo[0])
