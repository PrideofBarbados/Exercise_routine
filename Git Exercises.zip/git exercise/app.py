import streamlit as st
import pickle
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier

# Load the trained models
# Open the RandomForestClassifier model for ExerciseName

 
# Open the RandomForestClassifier model for ExerciseName
with open('RandomForestClassifier_ExerciseName.pkl', 'rb') as pickle_in_ExerciseName:
    rfc_ExerciseName = pickle.load(pickle_in_ExerciseName)

# Open the RandomForestClassifier model for ExerciseImage
with open('RandomForestClassifier_ExerciseImage.pkl', 'rb') as pickle_in_ExerciseImage:
    rfc_ExerciseImage = pickle.load(pickle_in_ExerciseImage)

# Open the RandomForestClassifier model for Equipment
with open('RandomForestClassifier_Equipment.pkl', 'rb') as pickle_in_Equipment:
    rfc_Equipment = pickle.load(pickle_in_Equipment)

# Open the RandomForestClassifier model for level
with open('RandomForestClassifier_level.pkl', 'rb') as pickle_in_level:
    rfc_level = pickle.load(pickle_in_level)

# Open the RandomForestClassifier model for Description
with open('RandomForestClassifier_Description.pkl', 'rb') as pickle_in_Description:
    rfc_Description = pickle.load(pickle_in_Description)

# Open the RandomForestClassifier model for Duration
with open('RandomForestClassifier_Duration.pkl', 'rb') as pickle_in_Duration:
    rfc_Duration = pickle.load(pickle_in_Duration)

# Open the RandomForestClassifier model for DaysPerWeek
with open('RandomForestClassifier_DaysPerWeek.pkl', 'rb') as pickle_in_DaysPerWeek:
    rfc_DaysPerWeek = pickle.load(pickle_in_DaysPerWeek)

# Open the RandomForestClassifier model for TimePerWorkout
with open('RandomForestClassifier_TimePerWorkout.pkl', 'rb') as pickle_in_TimePerWorkout:
    rfc_TimePerWorkout = pickle.load(pickle_in_TimePerWorkout)

# Open the RandomForestClassifier model for RecommendedSupplements
with open('RandomForestClassifier_RecommendedSupplements.pkl', 'rb') as pickle_in_RecommendedSupplements:
    rfc_RecommendedSupplements = pickle.load(pickle_in_RecommendedSupplements)

# Open the RandomForestClassifier model for WorkoutPdfwithvideo
with open('RandomForestClassifier_WorkoutPdfwithvideo.pkl', 'rb') as pickle_in_WorkoutPdfwithvideo:
    rfc_WorkoutPdfwithvideo = pickle.load(pickle_in_WorkoutPdfwithvideo)


with open('df.pkl', 'rb') as pickle_in_exercise:
    exercise = pickle.load(pickle_in_exercise)

# Load the LabelEncoders for decoding predictions
# Load the LabelEncoder for 'ExerciseName'
with open('le_ExerciseName.pkl', 'rb') as encoder_file:
    encoder_ExerciseName = pickle.load(encoder_file)

# Load the LabelEncoder for 'ExerciseImage'
with open('le_ExerciseImage.pkl', 'rb') as encoder_file:
    encoder_ExerciseImage = pickle.load(encoder_file)

# Load the LabelEncoder for 'Equipment'
with open('le_Equipment.pkl', 'rb') as encoder_file:
    encoder_Equipment = pickle.load(encoder_file)

# Load the LabelEncoder for 'level'
with open('le_level.pkl', 'rb') as encoder_file:
    encoder_level = pickle.load(encoder_file)

# Load the LabelEncoder for 'Description'
with open('le_Description.pkl', 'rb') as encoder_file:
    encoder_Description = pickle.load(encoder_file)

# Load the LabelEncoder for 'Duration'
with open('le_Duration.pkl', 'rb') as encoder_file:
    encoder_Duration = pickle.load(encoder_file)


# Load the LabelEncoder for 'TimePerWorkout'
with open('le_TimePerWorkout.pkl', 'rb') as encoder_file:
    encoder_TimePerWorkout = pickle.load(encoder_file)

# Load the LabelEncoder for 'RecommendedSupplements'
with open('le_RecommendedSupplements.pkl', 'rb') as encoder_file:
    encoder_RecommendedSupplements = pickle.load(encoder_file)

# Load the LabelEncoder for 'WorkoutPdfwithvideo'
with open('le_WorkoutPdfwithvideo.pkl', 'rb') as encoder_file:
    encoder_WorkoutPdfwithvideo = pickle.load(encoder_file)

## Load the LabelEncoder for 'Goal' (input feature)
with open('le_Goal.pkl', 'rb') as encoder_file:
    encoder_Goal = pickle.load(encoder_file)

# Load the LabelEncoder for 'Gender' (input feature)
with open('le_Gender.pkl', 'rb') as encoder_file:
    encoder_Gender = pickle.load(encoder_file)

exercise_df = pd.read_csv("git exercise.csv")

# Set feature names to None
rfc_ExerciseName.feature_names_in_ = None
rfc_ExerciseImage.feature_names_in_ = None
rfc_Equipment.feature_names_in_ = None
rfc_level.feature_names_in_ = None
rfc_Description.feature_names_in_ = None
rfc_Duration.feature_names_in_ = None
rfc_DaysPerWeek.feature_names_in_ = None
rfc_TimePerWorkout.feature_names_in_ = None
rfc_RecommendedSupplements.feature_names_in_ = None
rfc_WorkoutPdfwithvideo.feature_names_in_ = None

# Define the Streamlit app
st.title('Exercise Prediction App')
st.text("Designed by Project Team 1 Scrum Team 5")

# Define feature names in the correct order
feature_names = ['Gender', 'Goal','level']

# Input section
st.sidebar.header("INPUT YOUR DETAILS AND GOAL")
# Create select boxes for input features
selected_gender = st.sidebar.selectbox("What is your gender:", exercise_df['Gender'].unique())
#selected_goal = st.sidebar.selectbox("What do you want to achieve:", exercise_df['Goal'].unique())
# Filter workout goals based on the selected gender
available_goals = exercise_df[exercise_df['Gender'] == selected_gender]['Goal'].unique()
selected_goal = st.sidebar.selectbox("What do you want to achieve:", available_goals)

# Create a variable to store human-readable values for display
display_gender = selected_gender
display_goal = selected_goal


if st.sidebar.button("Ok"):
    encoded_gender = encoder_Gender.transform([selected_gender])[0]
    encoded_goal = encoder_Goal.transform([selected_goal])[0]

    # Filter exercises based on the selected gender
    filtered_exercise_df = exercise_df[(exercise_df['Gender'] == selected_gender) & (exercise_df['Goal'] == selected_goal)]

    if not filtered_exercise_df.empty:
        # Prepare input features for prediction
    # Prepare input features for prediction
        input_data = np.array([[encoded_gender,encoded_goal ]])

# Make predictions
        predicted_ExerciseName = encoder_ExerciseName.inverse_transform(rfc_ExerciseName.predict(input_data))
        selected_ExerciseName = predicted_ExerciseName[0]
        

# Display the predicted results
        # Display the selected predicted result
        st.subheader("Predicted Results:")
        st.write("Exercise Name:", selected_ExerciseName)
        # Fetch and display other details related to the predicted Exercise Name
        selected_exercise_details = exercise_df[exercise_df['ExerciseName'] == selected_ExerciseName].iloc[0]
        st.image(selected_exercise_details['ExerciseImage'])
        st.write('level:',selected_exercise_details['level'])
        st.write("Equipment:", selected_exercise_details['Equipment'])
        st.write("Description:", selected_exercise_details['Description'])
        st.write("Duration:", selected_exercise_details['Duration'])
        st.write("Days Per Week:", selected_exercise_details['DaysPerWeek'])
        st.write("Time Per Workout:", selected_exercise_details['TimePerWorkout'])
        st.write("Recommended Supplements:", selected_exercise_details['RecommendedSupplements'])
        
        
        # Check if the file is a PDF, a video, or a GIF
        file_extension = selected_exercise_details['WorkoutPdfwithvideo'].lower()
        # Check if the link contains 'bodybuilding.com' to identify external links
        if 'bodybuilding.com' in selected_exercise_details['WorkoutPdfwithvideo']:
     # Assume it's a web link, you can handle different types of links accordingly
            st.write("Workout PDF with Video:", selected_exercise_details['WorkoutPdfwithvideo'])
        else:
            if file_extension.endswith('.pdf'):
            # Display PDF if it's a PDF
                st.markdown(f'<iframe src="{selected_exercise_details["WorkoutPdfwithvideo"]}" width="700" height="500"></iframe>',
                            unsafe_allow_html=True)
            elif file_extension.endswith('.mp4'):
        # Display video if it's an MP4
                st.video(selected_exercise_details['WorkoutPdfwithvideo'])
            elif file_extension.endswith('.gif'):
        # Display GIF using st.image
                st.image(selected_exercise_details['WorkoutPdfwithvideo'])
       